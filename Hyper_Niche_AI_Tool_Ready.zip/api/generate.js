
export default function handler(req, res) {
    const { topic } = req.body;
    res.status(200).json({ content: 'Generated content for topic: ' + topic });
}
